/* Empty file present only to prevent linking libcustom from 0 files */
