/*
 *	Sherlock Gatherer -- Configuration of dumping the files
 *
 *	(c) 2001 Robert Spalek <robert@ucw.cz>
 */

extern char *terminal_charset;
extern uns line_len;
