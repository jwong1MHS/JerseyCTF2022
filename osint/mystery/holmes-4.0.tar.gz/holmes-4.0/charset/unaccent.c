/*
 *	The UniCode Library -- Unaccenting Table
 *
 *	(c) 1997 Martin Mares <mj@ucw.cz>
 *
 *	This software may be freely distributed and used according to the terms
 *	of the GNU Lesser General Public License.
 */

#include "ucw/lib.h"
#include "charset/unicat.h"
#include "charset/U-unacc.h"
